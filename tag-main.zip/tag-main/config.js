const CONFIG = {
    introTitle: 'Hi Ngân Trần',
    introDesc: `Chào mừng em đã
   đến với ngày kỉ niệm siêu khủng này`,
    btnIntro: 'Vào đê',
    title: 'Nhìn cái này quen hok cưng  🥰',
    desc: 'Phải chăng anh đã say ngay từ lúc thấy nụ cười ấy ',
    btnYes: 'Quen ạ , anh Đức iu của em 😘',
    btnNo: 'ĐÉO QUEN',
    question:'Gửi ảnh nú dè để tiếp tục',
    btnReply: 'Gửi cho anh đê',
    reply: 'Yêu thì yêu mà không yêu thì yêu cmn đi',
    mess: 'Anh biết mà mnem mnem * ực ực 😘😘',
    messDesc: 'Thế vẫn chỗ cũ nhá',
    btnAccept: 'Okiiiii lun <3',
    messLink: 'https://youtu.be/pqyBt0PbYJ0' //link mess của các bạn. VD: https://m.me/nam.nodemy
}
